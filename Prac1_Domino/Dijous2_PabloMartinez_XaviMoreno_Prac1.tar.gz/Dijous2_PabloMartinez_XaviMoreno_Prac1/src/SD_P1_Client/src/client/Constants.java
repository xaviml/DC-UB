package client;

/*
 * Client Side
 * This project is being developed by Pablo Martinez and Xavi Moreno
 */

/**
 * This class contains constants of aplication
 * 
 * @author Xavi Moreno
 */
public class Constants {
    public static final int TIMEOUT = 5000;
}
