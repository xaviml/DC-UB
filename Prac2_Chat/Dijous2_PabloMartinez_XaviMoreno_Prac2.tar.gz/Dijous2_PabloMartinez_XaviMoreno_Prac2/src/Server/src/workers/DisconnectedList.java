/*
 * Server Side
 * This project is being developed by Pablo Martinez and Xavi Moreno
 */

package workers;

/**
 *
 * @author kirtash
 */
public interface DisconnectedList {
    public void addDisconnected(String s);
}
