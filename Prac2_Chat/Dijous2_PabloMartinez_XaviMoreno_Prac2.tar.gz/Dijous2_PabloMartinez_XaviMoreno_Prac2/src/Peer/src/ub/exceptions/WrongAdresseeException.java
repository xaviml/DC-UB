/*
 * Peer Side
 * This project is being developed by Pablo Martinez and Xavi Moreno
 */

package ub.exceptions;

/**
 * 
 * @author Pablo Martinez
 */
public class WrongAdresseeException extends RuntimeException{
}
