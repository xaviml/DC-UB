/*
 * Common Side
 * This project is being developed by Pablo Martinez and Xavi Moreno
 */

package ub.common;

/**
 *
 * @author Pablo
 */
public class UserInUseException extends Exception {
    
}
